package com.package1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ClientSave {
	
	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Employee.class);
		
		SessionFactory factory=cfg.buildSessionFactory();
		
		Session session=factory.openSession();
		
		Transaction transcation=session.beginTransaction();
		
		Employee employee= new Employee(200, "kharat");
		
		session.save(employee);
		
		
		transcation.commit();  //Without this query data will not add in database as hibernet disabled cummit query 
		
		
		
	}

}
