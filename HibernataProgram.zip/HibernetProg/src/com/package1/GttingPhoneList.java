package com.package1;


import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class GttingPhoneList {
	
	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Phone.class);
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		
		Criteria criteria=session.createCriteria(Phone.class);
	
		List<Phone> phone=criteria.list();
	
		
		for (Phone  object : phone) {
			
			System.out.println(object);
			
		}
		
		
	}

}
