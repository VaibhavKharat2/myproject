package com.package1;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Phone {
	@Id
	private int Price;
	private String Name;
	public Phone() {
		super();
	}
	public Phone(int price, String name) {
		super();
		Price = price;
		Name = name;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	@Override
	public String toString() {
		return "Phone [Price=" + Price + ", Name=" + Name + "]";
	}
	
	

}
