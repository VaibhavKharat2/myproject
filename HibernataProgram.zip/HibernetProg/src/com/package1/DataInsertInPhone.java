package com.package1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DataInsertInPhone {
	
	public static void main(String[] args) {
		
		Configuration cfg = new    Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Phone.class);
		
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
	
		Transaction transcation=session.beginTransaction();
		
		Phone phone = new Phone(78, "Xiome");
		
		session.save(phone);
		transcation.commit();
		
		System.out.println("all the above data inserted in the databases:");
	}

}
