package com.package1;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



public class PrintingAll {
	
	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Employee.class);
		SessionFactory factory =cfg.buildSessionFactory();
		Session session=factory.openSession();
		
		Criteria criteria=session.createCriteria(Employee.class);
		
		List<Employee> employee=criteria.list();  // for printing all data
		
		for(Employee al : employee)
			System.out.println(al);
	}

}
